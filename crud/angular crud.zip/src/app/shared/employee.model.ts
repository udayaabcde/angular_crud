
export class Employee {
    EmployeeID!: any;
    FullName!: string;
    Position!: string;
}